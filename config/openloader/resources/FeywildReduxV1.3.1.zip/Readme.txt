This pack is intended to be used with the Feywild Mod:
https://www.curseforge.com/minecraft/mc-mods/feywild